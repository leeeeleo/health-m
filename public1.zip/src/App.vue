<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'


</script>

<template>
  <RouterView />
</template>

<style scoped>

</style>
