<template>
    <div class="advicecontent" style="display: none;" >
    <div class="gangnyc">
        <div class="gangnyctxt">肝功能异常</div>
        <div class="weihai">包括谷丙转氨酶升高、谷草转氨酶升高、胆红素升高、谷氨酰转肽酶升高，提示肝细胞可能损害</div>
        
    </div>
    <div class="advice"><img src="../../assets/images/icon_3.png" /><div class="advicetxt1">建议</div><br/><span class="advicetxt2">生活规律，适当休息,避免剧烈运动，减轻肝脏负担忌酒，多吃新鲜水果蔬菜，提供充足维生素，饮食宜清淡、易消化食物，尽量避免传染病，如感冒、肠道疾病等，因为感染可加重肝脏负担。
定期肝功能以及肝脏B超复查。必要时肝科专科诊疗。</span>
        <div class="ckgd">查看更多</div>
    </div>
    
    </div>
    <div style="display: none;" class="banner"><img src="../../assets/images/banner_1.png" /></div>


    <div class="advicemore"><img src="../../assets/images/icon_3.png" /><div class="advicetxt1">建议</div><br/><span class="advicetxt2">一、合理膳食、食饮有节。合理膳食是按照不同年龄、身体活动和身体状况，来确定三餐食物搭配和比例，以最大程度地保障人体营养与健康需要。食物多样、规律饮食、食饮有节是保证营养平衡和身体健康的基础。偏食、过度的摄入食物、饮料、饮酒等，都会带来消化系统的负担，造成营养不良、肥胖等慢性疾病的发生发展。
建议大家饮食上要食物多样，合理搭配，定时定量；细嚼慢咽、享受食物美好；成人每天饮水7至8杯（1500至1700毫升），饮用白开水或茶水。尽量减少酒类摄入，儿童青少年、孕妇、哺乳的母亲不应饮酒。倡导平衡膳食和健康生活方式，打好全家健康基础。</span>
        <div class="ckgd">查看更多</div></div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import './detailed.css'

export default defineComponent({})
</script>