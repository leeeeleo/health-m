export const outputDir = 'dist';
export const assetsDir = 'static';
export const parallel = false;
export const publicPath = './';